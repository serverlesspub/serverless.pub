module.exports = (body, statusCode) => {
	return Promise.resolve({
		statusCode: (statusCode || 200),
		body: body,
		headers: {
			'Content-Type': 'text/html'
		}
	});
};

