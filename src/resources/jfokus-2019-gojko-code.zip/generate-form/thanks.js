'use strict';
const htmlResponse = require('./html-response'),
	AWS = require('aws-sdk'),
	EXTENSION = process.env.EXTENSION,
	s3 = new AWS.S3();

exports.handler = (event /*, context*/) => {
	const key = event.queryStringParameters.key,
		resultKey = key.replace(/\.[^.]+$/, EXTENSION),
		params = {Bucket: process.env.RESULT_S3_BUCKET, Key: resultKey, Expires: 600},
		url = s3.getSignedUrl('getObject', params),
		responseText = `
			<html><body>
			<h1>Thanks</h1>
			<a href="${url}">check your result</a>
			</body></html>
		`;
	return htmlResponse(responseText);
};
