'use strict';
const htmlResponse = require('./html-response'),
	buildHtmlForm = require('./build-form'),
	aws = require('aws-sdk'),
	uploadLimitInMB = process.env.UPLOAD_LIMIT_IN_MB || 5,
	s3 = new aws.S3();

exports.handler = (event, context) => {
	const reference = context.awsRequestId,
		params = {
			Bucket: process.env.UPLOAD_S3_BUCKET,
			Expires: 3600,
			Conditions: [
				['content-length-range', 1, uploadLimitInMB * 1000000]
			],
			Fields: {
				success_action_redirect: `https://${event.headers.Host}/${event.requestContext.stage}/thanks`,
				'acl': 'private',
				key: `${reference}.jpg`
			}
		},
		form = s3.createPresignedPost(params),
		responseHtml = buildHtmlForm(form);

	return htmlResponse(responseHtml);
};
